export default function AboutPage() {
  return (
    <div className="container pt-24 pb-12 flex items-center justify-center min-h-screen">
      <div className="text-center">
        <h1 className="text-title-medium">关于页面</h1>
        <p className="text-body-large text-muted-foreground mt-2">此页面正在开发中。</p>
      </div>
    </div>
  )
}
